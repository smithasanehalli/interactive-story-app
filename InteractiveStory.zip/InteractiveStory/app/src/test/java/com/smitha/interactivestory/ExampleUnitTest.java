package com.smitha.interactivestory;

import org.junit.Test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;

import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
public class ExampleUnitTest {
    @Test
    public void exampleTest() {
        assertTrue(true);
    }

    @Test
    public void exampleTestinvalid() {
        assertTrue(false);
    }
}